// document.addEventListener('DOMContentLoaded', function () {
//   const wishlistDrawer = document.getElementById('wishlist-drawer');
//   const wishlistDrawerEmpty = document.getElementById('drawer_empty');
//   const wishlistIcon = document.getElementById('wishlist-icon');
//   const wishlistCount = document.getElementById('wishlist-count');
//   const closeWishlistDrawer = document.getElementById('close-wishlist-drawer');
//   const wishlistItems = document.getElementById('wishlist-items');
//   const wishlistPopup = document.getElementById('wishlist-popup');
//   const wishlistPopupMessage = document.getElementById('wishlist-popup-message');
//   const wishlistPopupClose = document.getElementById('wishlist-popup-close');
//   const cartDrawer = document.querySelector('cart-drawer') || null;
//   let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

//   const showLoader = (button) => {
//     const loader = button.querySelector('.loading__spinner');
//     if (loader) {
//       loader.classList.remove('hidden');
//       button.classList.add('hidden-icon');
//     }
//   };

//   const hideLoader = (button) => {
//         // Check if the button element exists before accessing its properties
//         if (button && button.querySelector) {
//             const loader = button.querySelector('.loading__spinner');
//             if (loader) {
//                 loader.classList.add('hidden');
//                 button.classList.remove('hidden-icon');
//             }
//         } 
//     };

//   const updateWishlistCount = () => {
//     if (wishlistCount) {
//       wishlistCount.textContent = wishlist.length;
//     }
//     if (wishlist.length > 0) {
//       wishlistDrawerEmpty.classList.add('hide');
//     } else {
//       wishlistDrawerEmpty.classList.remove('hide');
//     }
//     toggleHeaderWishlistIcons();
//   };


//   const renderWishlistItems = () => {
//     if (wishlistItems) {
//       wishlistItems.innerHTML = '';
//       wishlist.forEach(item => {
//         const li = document.createElement('li');
//         li.innerHTML = `
//           <div class="product_container">
//             <div class="product_flex">
//               <div class="product_col left_col">
//                 <div class="product_img">
//                   <img src="${item.image}" alt="${item.title}">
//                 </div>
//               </div>
//               <div class="product_col right_col">
//                 <div class="product_flex_inner">
//                   <div class="inner_left">
//                     <div class="product_vendor caption-with-letter-spacing light">${item.vendor}</div>
//                     <div class="product_title">
//                       <a href="${item.handle}">
//                         <h3 class="cart-item__name h4 break">${item.title}</h3>
//                       </a>
//                     </div>
//                     <div class="product_price product-option">${item.price}</div>
//                   </div>
//                   <div class="inner_right">
//                     <div class="product_remove">
//                       <button class="remove-wishlist-item button" data-product-id="${item.id}">
//                         <svg fill="none" height="24" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg">
//                           <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
//                         </svg>
//                         <div class="loading__spinner hidden">
//                           <svg
//                             aria-hidden="true"
//                             focusable="false"
//                             class="spinner"
//                             viewBox="0 0 66 66"
//                             xmlns="http://www.w3.org/2000/svg"
//                           >
//                             <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
//                           </svg>
//                         </div>
//                       </button>
//                     </div>
//                   </div>
//                 </div>
//                 <div class="product_cart_btn">
//                   <button class="add-to-cart wishlist-add-to-cart button" data-product-id="${item.id}">
//                     <span>Add to Cart</span>
//                     <div class="loading__spinner hidden">
//                       <svg
//                         aria-hidden="true"
//                         focusable="false"
//                         class="spinner"
//                         viewBox="0 0 66 66"
//                         xmlns="http://www.w3.org/2000/svg"
//                       >
//                         <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
//                       </svg>
//                     </div>
//                   </button>
//                 </div>
//               </div>
//             </div>
//           </div>
//         `;
//         wishlistItems.appendChild(li);
//       });
//     }
//   };

//   const saveWishlist = () => {
//     localStorage.setItem('wishlist', JSON.stringify(wishlist));
//   };

//   const toggleWishlistDrawer = () => {
//     if (wishlistDrawer) {
//       wishlistDrawer.classList.toggle('active');
//       const BodyEl = document.querySelector('body');
//       BodyEl.classList.toggle('overflow-hidden');
//     }
//   };
  
//   const closePopupAfterDelay = () => {
//       setTimeout(() => {
//           closeWishlistPopup();
//       }, 2000); // Close after 2 seconds
//   };

//     const showWishlistPopup = (product) => {
//     const popupMessage = document.getElementById('wishlist-popup-message');
//     const popupImg = popupMessage.querySelector('.popup_img');
//     const popupTitleMessage = popupMessage.querySelector('.popup_title_message');
  
//     if (popupImg && popupTitleMessage) {
//       popupImg.src = product.image;
//       popupImg.width = "100"; // Adjust the width as needed
//       popupImg.height = "100"; // Adjust the height as needed
//       popupImg.alt = product.title;
  
//       popupTitleMessage.textContent = `${product.title} ${product.message}`;
//     }
  
//     wishlistPopup.style.display = 'block';
//     closePopupAfterDelay(); // Call function to close popup after delay
//   };
  
  
//   const closeWishlistPopup = () => {
//     if (wishlistPopup) {
//       wishlistPopup.style.display = 'none';
//     }
//   };

//   const toggleHeaderWishlistIcons = () => {
//     const wishlistEmptyIcon = document.getElementById('wishlist-empty-icon');
//     const wishlistFilledIcon = document.getElementById('wishlist-filled-icon');
//     if (wishlist.length > 0) {
//       wishlistEmptyIcon.style.display = 'none';
//       wishlistFilledIcon.style.display = 'block';
//     } else {
//       wishlistEmptyIcon.style.display = 'block';
//       wishlistFilledIcon.style.display = 'none';
//     }
//   };

//   const toggleProductWishlistIcons = () => {
//     document.querySelectorAll('.wishlist-icon').forEach(button => {
//       const productId = button.dataset.productId;
//       const isInWishlist = wishlist.some(item => item.id === productId);
//       const emptyIcon = button.querySelector('.icon-heart');
//       const filledIcon = button.querySelector('.icon-heart-filled');
//       const textSpan = button.querySelector('.wishlist-text');
//       if (isInWishlist) {
//         emptyIcon.style.display = 'none';
//         filledIcon.style.display = 'block';
//         if (textSpan) {
//           textSpan.textContent = 'Added';
//         }
//       } else {
//         emptyIcon.style.display = 'block';
//         filledIcon.style.display = 'none';
//         if (textSpan) {
//           textSpan.textContent = 'Add to wishlist';
//         }
//       }
//     });
//   };

//   const handleAddToCart = (productId) => {
//     const product = wishlist.find(item => item.id === productId);
//     if (!product) return;
    
//     const formData = new FormData();
//     formData.append('id', product.id);
//     formData.append('quantity', 1);
    
//     if (cartDrawer) {
//       formData.append(
//         'sections',
//         cartDrawer.getSectionsToRender().map((section) => section.id)
//       );
//       formData.append('sections_url', window.location.pathname);
//       cartDrawer.setActiveElement(document.activeElement);
//     }

//     const config = fetchConfig('javascript');
//     config.headers['X-Requested-With'] = 'XMLHttpRequest';
//     delete config.headers['Content-Type'];
//     config.body = formData;

//      const addToCartButton = document.querySelector(`.add-to-cart[data-product-id="${productId}"]`);
//      showLoader(addToCartButton);

    
//     fetch(`${routes.cart_add_url}`, config)
//       .then((response) => response.json())
//       .then((response) => {
//         if (response.status) {
//             showWishlistPopup('Error adding product to cart.');
//           return;
//         }

//         if (!cartDrawer) {
//           window.location = window.routes.cart_url;
//           return;
//         }

//         cartDrawer.renderContents(response);
//         cartDrawer.classList.add('active');
//         cartDrawer.classList.remove('is-empty');
//       })
//       .catch((e) => {
//         console.error(e);
//         showWishlistPopup('Error adding product to cart.');
//       })
//       .finally(() => {
//         hideLoader(addToCartButton);
//         hideLoader(document.querySelector(`[data-product-id="${productId}"] .add-to-cart`));
//         toggleWishlistDrawer();
//       });
//   };

//   if (wishlistIcon) {
//     wishlistIcon.addEventListener('click', toggleWishlistDrawer);
//   }

//   if (closeWishlistDrawer) {
//     closeWishlistDrawer.addEventListener('click', toggleWishlistDrawer);
//   }

//   if (wishlistPopupClose) {
//     wishlistPopupClose.addEventListener('click', closeWishlistPopup);
//   }

//   document.querySelectorAll('.wishlist-icon').forEach(button => {
//     button.addEventListener('click', function () {
//       showLoader(button);
//       setTimeout(() => {
//         const productId = this.dataset.productId;
//         const product = {
//           id: productId,
//           title: this.dataset.productTitle,
//           image: this.dataset.productImage,
//           vendor: this.dataset.productVendor,
//           handle: this.dataset.productHandle,
//           price: this.dataset.productPrice
//         };
//         const isInWishlist = wishlist.some(item => item.id === productId);
//         const popupMessage = document.getElementById('wishlist-popup-message');
//         const addMessage = popupMessage.getAttribute('add-m');
//         const removeMessage = popupMessage.getAttribute('remove-m');
//         if (isInWishlist) {
//           wishlist = wishlist.filter(item => item.id !== productId);
//           if (popupMessage) {
//            showWishlistPopup({
//                 image: product.image,
//                 title: product.title,
//                 message: removeMessage
//             });
//           }
//         } else {
//           wishlist.push(product);
//           if (popupMessage) {
//             showWishlistPopup({
//                 image: product.image,
//                 title: product.title,
//                 message: `${product.title} ${addMessage}`
//             });
//           }
//         }
//         saveWishlist();
//         updateWishlistCount();
//         renderWishlistItems();
//         toggleProductWishlistIcons();
//         hideLoader(button);
//         setTimeout(closeWishlistPopup, 3000); // Automatically close after 3 seconds
//       }, 2000); // 2 second delay
//     });
//   });
  
//    const handleRemoveFromWishlist = (RemoveButton) => {
//         showLoader(RemoveButton); // Show loader when removing from wishlist
//         setTimeout(() => {
//             hideLoader(RemoveButton); // Hide loader after removing from wishlist
//         }, 2000); // 2 second delay
//     };
  
//   if (wishlistDrawer) {
//     wishlistDrawer.addEventListener('click', function (event) {
//       if (event.target.classList.contains('remove-wishlist-item')) {
//         console.log("Yes Click Remove!");
//         const button = event.target.closest('.wishlist-icon');
//         const RemoveButton = event.target;
//         handleRemoveFromWishlist(RemoveButton);
//         setTimeout(() => {
//           const productId = event.target.dataset.productId;
//           wishlist = wishlist.filter(item => item.id !== productId);
//           saveWishlist();
//           updateWishlistCount();
//           renderWishlistItems();
//           toggleProductWishlistIcons();
//         }, 2000); // 2 second delay
//       } else if (event.target.classList.contains('add-to-cart')) {
//         const productId = event.target.dataset.productId;
//         // Add to cart logic here
//         console.log(`Added product ${productId} to cart`);
//         handleAddToCart(productId);
//       }
//     });
//   }

//   updateWishlistCount();
//   renderWishlistItems();
//   toggleProductWishlistIcons();
// });